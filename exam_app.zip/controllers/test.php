<?php
class FILEEXCL extends MY_Controller{
}