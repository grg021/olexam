<html>



    <head>



        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title><?php echo $title?></title>

		<link href= "/css/swp_mainpage.css" rel="stylesheet" type="text/css" />

<!--[if lt IE 8]>
<style type="text/css">
#xouter{display:block}
#xcontainer{top:50%;display:block}
#xinner{top:-50%;position:relative}
</style>

<![endif]-->
<!--[if IE 7]>
<style type="text/css">
#xouter{
position:relative;
/*overflow:hidden;*/
}
</style>
<![endif]-->

        <!-- ** CSS ** -->
        <link rel="stylesheet" type="text/css" href="/js/ext34/resources/css/ext-all.css" />

        <!-- overrides to base library -->



<style type="text/css">

</style></head>

<body>

<!-- ** Javascript ** -->

        <!-- ExtJS library: base/adapter -->

        <!-- <script type="text/javascript" src="/js/ext34/adapter/ext/ext-base.js"></script>-->

        

        <!-- ExtJS library: all widgets -->
        
        <script type="text/javascript" src="/js/ext34/adapter/ext/ext-base.js"></script>

        <script type="text/javascript" src="/js/commonjs/ExtCommon.js"></script>

        <!-- ExtJS library: all widgets -->

        <script type="text/javascript" src="/js/ext34/ext-all-debug.js"></script>

        <!--<script type="text/javascript" src="/js/ext411/ext-all-debug.js"></script>

    	<script type="text/javascript" src="/js/compatibility/ext3-core-compat.js"></script>
		<script type="text/javascript" src="/js/compatibility/ext3-compat.js"></script>
		
		<script type="text/javascript" src="/js/commonjs/ExtCommon.js"></script>-->
<div id="maincontent">
	<h1>E-Online</h1>
<!--
  <div id="left">
	<h1>SWP</h1>
     <div id="object2"><img src="/images/ogslogo.png" /></div>

  </div>





  <div id="right">

    <div id="object1"><img src="/images/ogsrightheader.png" align="right"/></div>

  </div>-->
</div>
<div id="userControls">
</div>
<?php include_once 'menu.php'; ?>
    <?php echo $content_for_layout?>
<div id="mainfooter">

  <div align="center">Online Exam Tool v1 / COPYRIGHT &copy; 2012 Lithefire Solutions Inc.<br />

  <a href="http://www.lithefire.net">www.lithefire.net</a></div>
  </div>
  <div id="rightfooter">
    <div id="imagefooter"></div>
  </div>
</div>
</body>
</html>
